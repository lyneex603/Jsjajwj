1) Install JDK 25 and Maven.
2) In this folder run:  mvn package
3) Take target/RandomPortal-1.0.jar and put it into server plugins/
4) Restart server. Config: plugins/RandomPortal/config.yml (range: 2400)
